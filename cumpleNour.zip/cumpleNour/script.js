const REGALOS_ESTATICOS = [
    { id: 1, pista: "Algo para cubrir tus pies de las mordidas...", solucion: "zapatillas", revelado: "¡Tus nuevas Zapatillas de Superviviente!" },
    { id: 2, pista: "Suministro dulce altamente energético...", solucion: "chocolate", revelado: "¡Tu caja de bombones favorita!" },
    { id: 3, pista: "Para ver en la oscuridad de las alcantarillas...", solucion: "linterna", revelado: "¡Una Linterna Táctica de alta potencia!" }
];

let regalos = [];
let indexActivo = null;

// --- INICIO Y PERSISTENCIA ---
function cargarDatos() {
    const guardado = localStorage.getItem('juegoNour');
    if (guardado) {
        regalos = JSON.parse(guardado);
    } else {
        regalos = REGALOS_ESTATICOS.map(r => ({ ...r, intentos: 3, estado: 'pending' }));
        guardar();
    }
    if (document.getElementById('grid')) dibujarBoxes();
}

function guardar() { localStorage.setItem('juegoNour', JSON.stringify(regalos)); }

// --- INTERFAZ ---
function dibujarBoxes() {
    const grid = document.getElementById('grid');
    if (!grid) return;
    grid.innerHTML = '';
    regalos.forEach((r, i) => {
        const div = document.createElement('div');
        div.className = `box ${r.estado}`;
        div.innerHTML = `
            <div style="font-size: 2rem; margin-bottom: 5px;">
                ${r.estado === 'success' ? '✅' : (r.estado === 'failed' ? '💀' : '📦')}
            </div>
            <span>SUMINISTRO #${r.id}</span>
        `;
        div.onclick = () => abrirBox(i);
        grid.appendChild(div);
    });
}

function abrirBox(i) {
    indexActivo = i;
    const r = regalos[i];
    const overlay = document.getElementById('overlay');
    overlay.style.display = 'flex';
    
    document.getElementById('user-input').value = "";
    document.getElementById('msg').innerText = "";

    if (r.estado === 'pending') {
        document.getElementById('modal-title').innerText = "ENCRIPTADO";
        document.getElementById('modal-title').style.color = "#8a0b0b";
        document.getElementById('pista-texto').innerText = r.pista;
        document.getElementById('game-area').style.display = 'block';
        document.getElementById('result-area').style.display = 'none';
        document.getElementById('btn-volver-modal').innerText = "VOLVER";
    } else {
        mostrarResultado(r.estado === 'success' ? "ASEGURADO" : "PERDIDO", r.revelado, r.estado === 'success' ? "#4a5d23" : "#b58900");
    }
}

function validar() {
    const r = regalos[indexActivo];
    const input = document.getElementById('user-input').value.toLowerCase().trim();
    
    if (input.includes(r.solucion.toLowerCase())) {
        r.estado = 'success';
        mostrarResultado("¡ACCESO CONCEDIDO!", r.revelado, "#4a5d23");
    } else {
        r.intentos--;
        flashSangre();
        if (r.intentos <= 0) {
            r.estado = 'failed';
            mostrarResultado("SISTEMA BLOQUEADO", "Suministro perdido en la horda.", "#b58900");
        } else {
            const msg = document.getElementById('msg');
            msg.innerText = `¡ERROR! Te quedan ${r.intentos} vidas.`;
            msg.style.color = "#ff4444";
        }
    }
    guardar();
    dibujarBoxes();
}

function mostrarResultado(titulo, texto, color) {
    document.getElementById('game-area').style.display = 'none';
    document.getElementById('result-area').style.display = 'block';
    const t = document.getElementById('modal-title');
    t.innerText = titulo; t.style.color = color;
    document.getElementById('result-text').innerText = texto;
    document.getElementById('btn-volver-modal').innerText = "VOLVER AL MAPA";
}

function cerrarModal() { document.getElementById('overlay').style.display = 'none'; }

function cerrarBienvenida() {
    const welcome = document.getElementById('welcome-overlay');
    if (welcome) {
        welcome.style.opacity = "0";
        welcome.style.transition = "opacity 0.5s";
        setTimeout(() => welcome.style.display = "none", 500);
    }
}

function flashSangre() {
    const screen = document.getElementById('blood-screen');
    if (screen) {
        screen.classList.add('flash');
        setTimeout(() => screen.classList.remove('flash'), 500);
    }
}

// Admin: 5 clics en logo
let clicsLogo = 0;
function inicializarAdmin() {
    const logo = document.querySelector('.logo-text');
    if (logo) {
        logo.addEventListener('click', () => {
            clicsLogo++;
            if (clicsLogo === 5) {
                if (prompt("Clave:") === 'rick') {
                    localStorage.removeItem('juegoNour');
                    location.reload();
                }
                clicsLogo = 0;
            }
        });
    }
}

window.onload = () => { cargarDatos(); inicializarAdmin(); };